from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import SVC
from sklearn.pipeline import make_pipeline
import numpy as np
import random
from speech import speech_recognition
from speak import speak
from screenshort import take_screenshort
from brightness import increaseBrightness
from brightness import decreaseBrightness
from timeplease import timeIsMoney
from emailsend import emailme
from tarik import tarik_pe_tarik
from playsongs import gana_bajao
from openApplications import whatsapp, closewhatsapp, telegram, closetelegram, vscode, closevscode, taskmanager, closetaskmanager, camera, closecamera
from gemini import ansque
from gemImage import imageProcessing
from newsLine import newsRead
from eyeControl import eyeControl
from mouseControlUsingHand import handControl
from gemini import ansque


intents = {
    "greetings": {
        "patterns": ["hello", "hi", "hey", "howdy", "greetings", "good morning", "good afternoon", "good evening", "hi there", "hey there", "what's up", "hello there"],
        "responses": ["Hello! How can I assist you?", "Hi there!", "Hey! What can I do for you?", "Howdy! What brings you here?", "Greetings! How may I help you?", "Good morning! How can I be of service?", "Good afternoon! What do you need assistance with?", "Good evening! How may I assist you?", "Hey there! How can I help?", "Hi! What's on your mind?", "Hello there! How can I assist you today?"]
    },
    "goodbye": {
        "patterns": ["bye", "see you later", "goodbye", "farewell", "take care", "until next time", "bye bye", "catch you later", "have a good one", "so long"],
        "responses": ["Goodbye!", "See you later!", "Have a great day!", "Farewell! Take care.", "Goodbye! Until next time.", "Take care! Have a wonderful day.", "Bye bye!", "Catch you later!", "Have a good one!", "So long!"],
    },
    "gratitude": {
        "patterns": ["thank you", "thanks", "appreciate it", "thank you so much", "thanks a lot", "much appreciated"],
        "responses": ["You're welcome!", "Happy to help!", "Glad I could assist.", "Anytime!", "You're welcome! Have a great day.", "No problem!"]
    },
    "apologies": {
        "patterns": ["sorry", "my apologies", "apologize", "I'm sorry"],
        "responses": ["No problem at all.", "It's alright.", "No need to apologize.", "That's okay.", "Don't worry about it.", "Apology accepted."]
    },
    "positive_feedback": {
        "patterns": ["great job", "well done", "awesome", "fantastic", "amazing work", "excellent"],
        "responses": ["Thank you! I appreciate your feedback.", "Glad to hear that!", "Thank you for the compliment!", "I'm glad I could meet your expectations.", "Your words motivate me!", "Thank you for your kind words."]
    },
    "negative_feedback": {
        "patterns": ["not good", "disappointed", "unsatisfied", "poor service", "needs improvement", "could be better"],
        "responses": ["I'm sorry to hear that. Can you please provide more details so I can assist you better?", "I apologize for the inconvenience. Let me help resolve the issue.", "I'm sorry you're not satisfied. Please let me know how I can improve.", "Your feedback is valuable. I'll work on improving."]
    },
    "handControl": {
        "patterns": ["start hand control", "Start hand control", "hand control", "start mouse control using hand"],
        "responses": handControl
    },
    "help": {
        "patterns": ["help", "can you help me?", "I need assistance", "support"],
        "responses": ["Sure, I'll do my best to assist you.", "Of course, I'm here to help!", "How can I assist you?", "I'll help you with your query."]
    },
    "time": {
        "patterns": ["what's the time?", "current time", "time please", "what time is it?"],
        "responses": timeIsMoney,
    },
    "music": {
        "patterns": ["play music", "music please", "play songs", "on the music","on songs"],
        "responses": gana_bajao,
    },
    "news": {
        "patterns": ["latest news", "news updates", "what's happening?", "current events"],
        "responses": ["Let me fetch the latest news for you.", "Here are the top headlines: [news_headlines]", "Stay updated with the latest news!"]
    },
    "movies": {
        "patterns": ["movie suggestions", "recommend a movie", "what should I watch?", "best movies"],
        "responses": ["How about watching [movie_name]?", "Here's a movie suggestion for you.", "Let me recommend some great movies!"]
    },
    "email": {
        "patterns": ["send email", "email", "send mail", "email my friend"],
        "responses": emailme,
    },
        "tech_support": {
        "patterns": ["technical help", "computer issues", "troubleshoot", "IT support"],
        "responses": ["I can assist with technical issues. What problem are you facing?", "Let's troubleshoot your technical problem together.", "Tell me about the technical issue you're experiencing."]
    },
    "book_recommendation": {
        "patterns": ["recommend a book", "good books to read", "book suggestions", "what should I read?"],
        "responses": ["How about reading [book_title]?", "I've got some great book recommendations for you!", "Let me suggest some interesting books for you to read."]
    },
    "eyeControl": {
        "patterns": ["start eyeControl", "eyeControl", "open eyecontrol", "open eye control","start eye control"],
        "responses": eyeControl
    },
    "date": {
        "patterns": ["whats current date", "tell the date", "todays date", "aaj ki tarik"],
        "responses": tarik_pe_tarik,
    },
    "telegram": {
        "patterns": ["telegram", "open telegram", "launch telegram", "telegram"],
        "responses": telegram,
    },
    "closetelegram": {
        "patterns": ["close telegram", "close the telegram", "close telegram", "telegram close"],
        "responses": closetelegram,
    },
    "whatsapp": {
        "patterns": ["whatsapp", "open whatsapp", "launch whatsapp", "whatsapp"],
        "responses": whatsapp,
    },
    "whatsappClose": {
        "patterns": ["Close whatsapp", "close the whatsapp", "end whatsapp", "whatsapp close"],
        "responses": closewhatsapp,
    },
    "vscode": {
        "patterns": ["vs code", "open vs code", "launch vs code", "vs code"],
        "responses": vscode,
    },
    "closevscode": {
        "patterns": ["close vs code", "close the vs code", "close vs code", "vs code close"],
        "responses": closevscode,
    },
    "taskmanager": {
        "patterns": ["task manager", "open task manager", "launch task manager", "task manager"],
        "responses": taskmanager,
    },
    "closetaskmanager": {
        "patterns": ["close task manager", "close the task manager", "close task manager", "task manager close"],
        "responses": closetaskmanager,
    },
    "camera": {
        "patterns": ["camera", "open camera", "launch camera", "camera"],
        "responses": camera
    },
    "closecamera": {
        "patterns": ["close camera", "close the camera", "close camera", "camera close"],
        "responses": closecamera
    },
    "career_advice": {
        "patterns": ["job search help", "career guidance", "career change advice", "professional development"],
        "responses": ["I can provide career advice. What specific guidance do you need?", "Let's explore career opportunities together.", "Tell me about your career goals or concerns."]
    },
    "relationship_advice": {
        "patterns": ["relationship help", "love advice", "dating tips", "relationship problems"],
        "responses": ["Relationships can be complex. How can I assist you?", "I can offer advice on relationships and dating.", "Tell me about your relationship situation."]
    },
    "mental_health": {
        "patterns": ["mental health support", "coping strategies", "stress relief tips", "emotional well-being"],
        "responses": ["Mental health is important. How can I support you?", "I can provide guidance for managing stress and emotions.", "Let's talk about strategies for maintaining mental well-being."]
    },
    "question": {
        "patterns": ["Start wolframe alpha", "start alpha", "", "wolf frame alpha", "start wolf frame alpha", "wolframe alpha"],
        "responses": ansque
    },
    "finance_advice": {
        "patterns": ["financial planning help", "money management tips", "investment advice", "budgeting assistance"],
        "responses": ["I can provide guidance on financial matters. What specific advice do you need?", "Let's discuss your financial goals and plans.", "Tell me about your financial situation or goals."]
    },
    "screenshort": {
        "patterns": ["screenshort","Take a screenshort", "Take screenshort", "make a screenshort", "click the screenshort"],
        "responses": take_screenshort,
    },
    "increase_brightness": {
        "patterns": ["increase the brightness","make display more brighter", "can you increase the brightness"],
        "responses": increaseBrightness,
    },
    "decrease_brightness": {
        "patterns": ["decrease the brightness","decrease brightness", "can you decrease the brightness", "can you decrease brightness"],
        "responses": decreaseBrightness,
    },
    "getAnswer": {
        "patterns": ["Want to ask something","have an question", "need solution", "tell me something","Answer me","I have an question"],
        "responses": ansque,
    },
    "image_processing": {
        "patterns": ["Start image processing","Process image", "image identification", "do image processing"],
        "responses": imageProcessing,
    },
    "image_processing": {
        "patterns": ["Start image processing","Process image", "image identification", "do image processing"],
        "responses": imageProcessing,
    },
    "news": {
        "patterns": ["Latest headline","current news", "news", "tell the latest news", "what is todays news","read the news"],
        "responses": newsRead,
    },
    
}



training_data = []
target = []
for intent, data in intents.items():
    patterns = data["patterns"]
    responses = data["responses"]

    for pattern in patterns:
        training_data.append(pattern)
        target.append(intent)

vectorizer = CountVectorizer()
X = vectorizer.fit_transform(training_data)
classifier = make_pipeline(CountVectorizer(), SVC(kernel='linear'))
classifier.fit(training_data, target)

def get_intent_response(user_input):
    predicted_intent = classifier.predict([user_input])[0]
    response = intents[predicted_intent]["responses"]
    if callable(response):
        response()
        return
    elif isinstance(response, list):
        
        speak(random.choice(response))
    else:
        return response

while True:
    user_input = speech_recognition()
    if user_input.lower() == 'exit':
        speak("Goodbye!")
        print("AI Assistant: Goodbye!")
        break
    if "screenshot" in user_input.lower():
        take_screenshort()
    else:
        get_intent_response(user_input)

