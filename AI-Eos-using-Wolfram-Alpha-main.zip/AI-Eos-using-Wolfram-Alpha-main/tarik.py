from datetime import datetime
import calendar
from speak import speak

def tarik_pe_tarik():
  current_year = datetime.now().date().year
  current_month = datetime.now().date().month
  current_day = datetime.now().date().day
  months = calendar.month_name[current_month]
  print("Current date: "+str(current_day)+" "+ months+" "+ str(current_year) )
  ret = "Current date: "+str(current_day)+" "+ months+" "+ str(current_year)
  speak(ret)


# ****tarik pata kare****
  
# tarik_pe_tarik()