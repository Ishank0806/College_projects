
# AI-EOS-using-Wolfram-Alpha

AI EOS represents a significant leap forward in virtual assistant technology for desktop platforms. By prioritizing user interaction through voice commands and offering a comprehensive suite of functionalities, including communication, navigation, information retrieval, and advanced control mechanisms, AI EOS delivers a seamless user experience.


## Screenshots

![App Screenshot](/images/img1.png)
![App Screenshot](/images/img3.png)
![App Screenshot](/images/img4.png)


## These are the following modules used in AI EOS📚 :

[SpeechRecognisation](https://pypi.org/project/SpeechRecognition/) | [PyAudio](https://pypi.org/project/PyAudio/) | [pyttsx3](https://pypi.org/project/pyttsx3/) | [wolframalpha](https://pypi.org/project/wolframalpha/) | [genai](https://pypi.org/project/genai/) | [pyautogui](https://pypi.org/project/PyAutoGUI/) | [mediapipe](https://pypi.org/project/mediapipe/) | [cv2](https://pypi.org/project/opencv-python/) | [requests](https://pypi.org/project/requests/) | [smtplib](https://pypi.org/project/secure-smtplib/) | [pygame](https://pypi.org/project/pygame/) | [AppOpener](https://pypi.org/project/appopener/) | [screen_brightness_control](https://pypi.org/project/screen-brightness-control/) | [scikit-learn](https://pypi.org/project/scikit-learn/) 
## Features

- It can tell current time
- It can play music file in a particular directory where the songs are present
- It can open/close all the pc applications
- It can take screenshot
- Control the mouse cursor using eye and hand movements.
- Make a Google search
- Make a Youtube search
- It can tell the latest news
- It can check/find your Internet speed
- Can do image processing using Gemini applications
- Can answer to the basic question using WolframAlpha
- It can send emails




## Developer Contacts
### Github Link's
- [Aditya Nikhate](https://github.com/AdityaNikhate)
- [Pranit Channe](https://github.com/Pranitchanne17)
- [Krutik Vihirghare](https://github.com/krutik1712)
- [Ishank Mhashakhetri](https://github.com/Ishank0806)

### LinkedIn Link's
- [Aditya Nikhate](https://www.linkedin.com/in/aditya-nikhate/)
- [Pranit Channe](https://www.linkedin.com/in/pranit-channe-907919243/)
- [Krutik Vihirghare](https://www.linkedin.com/in/krutik-vihirghare-835a3b27a/)
- [Ishank Mhashakhetri](https://www.linkedin.com/in/ishank-mhashakhetri-1b1034219/)