import time
from speak import speak
Time = time.localtime()
 

def timeIsMoney():
  Time = time.localtime()
  currentTime = time.strftime("%H:%M:%S", Time)
  hours = time.strftime("%H",Time)
  mins = time.strftime("%M",Time)
  secs = time.strftime("%S",Time)

  finalString = "The current time is "+hours+" hours "+mins+" minuites "+ secs + " seconds."
  print(currentTime)
  speak(finalString)