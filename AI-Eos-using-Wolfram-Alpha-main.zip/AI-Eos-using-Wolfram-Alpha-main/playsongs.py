import os
import pygame

def play_all_songs(directory):
    pygame.mixer.init()

    songs_directory = os.path.join(directory, "songs")

    try:
        files = os.listdir(songs_directory)
    except FileNotFoundError:
        print(f"'songs' directory not found in: {songs_directory}")
        return

    
    mp3_files = [file for file in files if file.endswith(".mp3")]

    if not mp3_files:
        print("No MP3 files found in the 'songs' directory.")
        return

    for mp3_file in mp3_files:
        song_path = os.path.join(songs_directory, mp3_file)
        print(f"Playing: {mp3_file}")
        pygame.mixer.music.load(song_path)
        pygame.mixer.music.play()
        pygame.time.wait(5000)  

def gana_bajao():
    script_directory = os.path.dirname(__file__)
    play_all_songs(script_directory)

if __name__ == "__main__":
    gana_bajao()

