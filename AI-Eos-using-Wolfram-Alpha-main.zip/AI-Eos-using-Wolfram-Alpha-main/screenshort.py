import pyautogui 
import numpy as np 
import cv2 
from speak import speak
import random

def take_screenshort():
	
	num = int(random.random()*100) 

	image = pyautogui.screenshot() 

	image = cv2.cvtColor(np.array(image), 
						cv2.COLOR_RGB2BGR) 

	filename = 'image'+str(num)+'.png'
	cv2.imwrite(filename, image) 
	stringToPass = "done with the short"+filename;
	speak(stringToPass)

