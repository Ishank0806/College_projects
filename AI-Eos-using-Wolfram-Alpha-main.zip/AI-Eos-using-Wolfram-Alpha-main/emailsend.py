import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from speak import speak

def emailme():
    
    # Usage this information to send the mail
    subject = "Exciting News! Project Completed 🎉"
    body = "I hope this email finds you well! I'm thrilled to share some fantastic news with you that the project we've been working on is officially completed!"
    to_email = "adityavijaynikhate@gmail.com"
    # cc_email = "cc@example.com"

    try:
        s = smtplib.SMTP('smtp.gmail.com', 587)
        s.starttls()
        s.login("ytvanced69k@gmail.com", "csjd vlmg pwhl xvrv")
        
        message = MIMEMultipart()
        message['From'] = "ytvanced69k@gmail.com"
        message['To'] = to_email
        # message['Cc'] = cc_email if cc_email else ""
        message['Subject'] = subject
        
      
        message.attach(MIMEText(body, 'plain'))
        s.sendmail("ytvanced69k@gmail.com", to_email, message.as_string())
        print("Email sent successfully!")
        str = "Email sent successfully to "+ to_email
        speak(str)

    except Exception as e:
        print(f"An error occurred: {str(e)}")
        speak("Sorry the email can't be sent.")
    finally:
        s.quit()


# emailme()

