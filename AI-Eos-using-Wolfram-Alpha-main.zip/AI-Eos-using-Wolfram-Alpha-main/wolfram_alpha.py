import wolframalpha
from speak import speak
from speech import speech_recognition


app_id = 'API_KEY'

client = wolframalpha.Client(app_id)

def wolfQue():
  while(True):
    speak("What you want to know?")
    question = speech_recognition()
    if question.lower() in 'exit':
        break
    else:
      try:
        res = client.query(question)
        answer = next(res.results).text 
        speak(answer)

      except:
        print("Problem occure in the code.")

