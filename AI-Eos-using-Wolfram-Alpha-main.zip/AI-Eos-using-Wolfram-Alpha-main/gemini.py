import google.generativeai as genai
from speak import speak
from speech import speech_recognition

def ansque():
    while(True):
        speak("What's your question")
        query  = speech_recognition()
        genai.configure(api_key="API_KEY")
        model = genai.GenerativeModel('gemini-pro')
        if query.lower() in 'exit':
            break
        else:
            response = model.generate_content(query)
            response =  response.text
            response = response.replace("**", "")
            response = response.replace("//", "")
            response = response.replace("'''", "")

            if len(response) > 200:
                response = response[:200]

            print(response)
            speak(response)



