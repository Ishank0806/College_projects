import requests
from PIL import Image
import google.generativeai as genai

genai.configure(api_key="AIzaSyC0Qiqgwzn0rSBo5E_-CmnkL9W2rgVfV44")
model = genai.GenerativeModel('gemini-pro-vision')
# response = requests.get('https://newsapi.org/v2/top-headlines?country=in&apiKey=c5bc94fb69204065be524d5aceb48fb3&size')


print("EOS: Good Morning!")
print("EOS: Hello!, I am AI EOS. Please tell me how may I help you")
print("Listening...")
print("Recognizing...")
print("User said: start image processing")
print("EOS: starting image processing")
print("EOS: What You want to know?")
print("Listening...")
print("Recognizing...")
print("User said: discribe the image")
img = Image.open("mainI.jpg")
response = model.generate_content(["discribe the image breafly", img])
print("EOS: ",response.text)
print("Listening...")
print("Recognizing...")
print("User said: how many person you can see in Image")
response = model.generate_content(["how many person you can see in Image", img])
print("EOS: ",response.text)


    
