import requests
from speak import speak


response = requests.get('NEWS_API_LINK')


def newsRead():
    if response.status_code == 200:
        articles = response.json().get('articles', [])
  
        for article in articles[:3]:
            title = article.get('title', 'Title not available')
            url = article.get('url', 'URL not available')
            print(f"Title: {title}")
            speak(title)
            print()
            return

    else:
        print("Failed to fetch data from the News API.")
        return
