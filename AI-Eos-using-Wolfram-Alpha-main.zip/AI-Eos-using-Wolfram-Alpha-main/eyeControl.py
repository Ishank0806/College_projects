import cv2
import mediapipe as mp
import pyautogui

def eyeControl():
    cam = cv2.VideoCapture(0)
    face_mesh = mp.solutions.face_mesh.FaceMesh(refine_landmarks=True)
    hands = mp.solutions.hands.Hands()
    screen_w, screen_h = pyautogui.size()

    while True:
        _, frame = cam.read()
        frame = cv2.flip(frame, 1)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        face_output = face_mesh.process(rgb_frame)
        landmark_points = face_output.multi_face_landmarks

        hand_output = hands.process(rgb_frame)
        hand_landmark_points = hand_output.multi_hand_landmarks

        frame_h, frame_w, _ = frame.shape

        if landmark_points:
            landmarks = landmark_points[0].landmark
            for id, landmark in enumerate(landmarks[474:478]):
                x = int(landmark.x * frame_w)
                y = int(landmark.y * frame_h)
                cv2.circle(frame, (x, y), 3, (0, 255, 0))

                if id == 1:
                    screen_x = screen_w * landmark.x
                    screen_y = screen_h * landmark.y
                    pyautogui.moveTo(screen_x, screen_y)

            left = [landmarks[145], landmarks[159]]
            for landmark in left:
                x = int(landmark.x * frame_w)
                y = int(landmark.y * frame_h)
                cv2.circle(frame, (x, y), 3, (0, 255, 255))

            if (left[0].y - left[1].y) < 0.004:
                print("Left clicked performed")
                pyautogui.click()
                

            right = [landmarks[145], landmarks[159]]
            for landmark in right:
                x = int(landmark.x * frame_w)
                y = int(landmark.y * frame_h)
                cv2.circle(frame, (x, y), 3, (0, 255, 255))

            if (right[0].y - right[1].y) < 0.004:
                print("Right click performed")
                pyautogui.rightClick()
                # pyautogui.sleep()

        # Check if hands are detected
        if hand_landmark_points:
            print("Hand detected. Exiting the script.")
            break

        cv2.imshow('Eye controlled mouse', frame)
        key = cv2.waitKey(1)
        if key == ord('q'):
            break

    cam.release()
    cv2.destroyAllWindows()
  

