from AppOpener import open,close
from speak import speak

def vscode():
  speak("opening visual studio code")
  open("visual studio code")

def closevscode():
  speak("Closing visual studio code")
  close("visual studio code")

def whatsapp():
  speak("opening whatsapp")
  open("whatsapp")

def closewhatsapp():
  speak("closing whatsapp")
  close("whatsapp")

def telegram():
  speak("opening telegram")
  open("telegram")


def closetelegram():
  speak("closing telegram")
  close("telegram")

def taskmanager():
  speak("opening task manager")
  open("Task Manager")

def closetaskmanager():
  speak("closeing task manager")
  close("taskmanager")

def camera():
  speak("opening camera")
  open("Camera")


def closecamera():
  speak("closeing camera")
  close("Camera")


