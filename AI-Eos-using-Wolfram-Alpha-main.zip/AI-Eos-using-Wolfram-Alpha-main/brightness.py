import screen_brightness_control as sbc
from speak import speak


current_brightness = sbc.get_brightness()
# print(current_brightness[0])

# To increase the brightness by value 10
def increaseBrightness():
  sbc.set_brightness(current_brightness[0]+10)
  speak("Increase the brightness Successfully")


# To decrease the brightness by value 10
def decreaseBrightness():
  sbc.set_brightness(current_brightness[0]-10)
  speak("Decrease brightness successfully")

# Calling the below function one-by-one to get result 
# *****For testing purpose
# increaseBrightness()
# decreaseBrightness()