import io
import cv2
from google.cloud import vision_v1
from google.cloud.vision_v1 import types
import pyttsx3

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0])


def speak(audio):
    engine.say(audio)
    engine.runAndWait()


try:
    client = vision_v1.ImageAnnotatorClient()
except Exception as e:
    print("Error: Failed to authenticate with Google Cloud Vision API. Please check your credentials.")
    exit()


def detect_faces(frame):
    success, encoded_image = cv2.imencode('.jpg', frame)
    image = types.Image(content=encoded_image.tobytes())
    response = client.face_detection(image=image)
    faces = response.face_annotations
    return faces

video = cv2.VideoCapture(0)

while True:
    ret, frame = video.read()
    faces = detect_faces(frame)
    
    for face in faces:
        vertices = [(vertex.x, vertex.y) for vertex in face.bounding_poly.vertices]
        cv2.rectangle(frame, vertices[0], vertices[2], (0, 255, 0), 2)
        speak("I see a face")

    cv2.imshow('Face Recognition', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

video.release()
cv2.destroyAllWindows()
