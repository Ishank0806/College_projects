import cv2
import numpy as np
import pyttsx3

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0])


def speak(audio):
    engine.say(audio)
    engine.runAndWait()


face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')


recognizer = cv2.face.LBPHFaceRecognizer_create()

images = []
labels = []


images.append(cv2.imread('faceimg/obama.jpeg', cv2.IMREAD_GRAYSCALE))
labels.append(0)  # Label for 'obama'
images.append(cv2.imread('faceimg/kristen.jpeg', cv2.IMREAD_GRAYSCALE))
labels.append(1)  # Label for 'kristen'

# Train the face recognition model
recognizer.train(images, np.array(labels))


video = cv2.VideoCapture(0)

while True:
    ret, frame = video.read()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    for (x, y, w, h) in faces:
        
        roi_gray = gray[y:y + h, x:x + w]
        label, confidence = recognizer.predict(roi_gray)

        
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        
        if confidence < 100:
            if label == 0:
                name = "obama"
            elif label == 1:
                name = "kristen"
            else:
                name = "Unknown"
            cv2.putText(frame, f'Good morning, {name}', (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
            speak(f"Good morning, {name}")
        else:
            cv2.putText(frame, 'User not authenticated', (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)
            speak('User not authenticated')

    cv2.imshow('Face Recognition', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break


video.release()
cv2.destroyAllWindows()
