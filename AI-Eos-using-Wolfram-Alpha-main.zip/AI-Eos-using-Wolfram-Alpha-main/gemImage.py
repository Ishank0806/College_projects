import cv2
from PIL import Image
import google.generativeai as genai
from speak import speak
from speech import speech_recognition

genai.configure(api_key="API_KEY")
model = genai.GenerativeModel('gemini-pro-vision')


def capture_image():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Failed to open camera")
        return None

    ret, frame = cap.read()
    if ret:
        cv2.imwrite("captured_image.jpg", frame)
        cap.release()
        cv2.destroyAllWindows()
        return "captured_image.jpg"
    else:
        print("Failed to capture image")
        return None


# def imageProcessing():
#     prompt = "Describe the image in detail: "
    
#     image_path = capture_image()
#     if image_path:
#         img = Image.open(image_path)
#         speak("What you want to know?")
#         prompt2 = speech_recognition()
#         response = model.generate_content([prompt2, img])
#         print(response.text)
#         speak(response.text)

def imageProcessing():
    image_path = capture_image()
    if image_path:
        while(True):
            speak("What you want to know?")
            prompt2 = speech_recognition()
            if prompt2.lower() == 'exit':
                break
            else:
                img = Image.open(image_path)
                response = model.generate_content([prompt2, img])
                print(response.text)
                speak(response.text[:200])

# imageProcessing()