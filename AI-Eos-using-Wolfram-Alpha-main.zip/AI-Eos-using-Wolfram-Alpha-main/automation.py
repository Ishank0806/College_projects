# import pyttsx3
# import speech_recognition as sr
# from selenium import webdriver
# from webdriver_manager.chrome import ChromeDriverManager
# from selenium.common.exceptions import NoSuchElementException
# from time import sleep

# def speak(text):
#     engine = pyttsx3.init()
#     Id = r'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices\Tokens\TTS_MS_EN-US_DAVID_11.0'
#     engine.setProperty('voice',Id)
#     print("")
#     print(f"==> Eos AI : {text}")
#     print("")
#     engine.say(text=text)
#     engine.runAndWait()

# def speechrecognition():
#     r = sr.Recognizer()
#     with sr.Microphone() as source:
#         print("Listening.....")
#         r.pause_threshold = 1
#         audio = r.listen(source,0,5)

#     try:
#         print("Recogizing....")
#         query = r.recognize_google(audio,language="en")
#         print(f"==> Person : {query}")
#         return query.lower()

#     except:
#         return ""


# def play_youtube_video(query):
#     driver = webdriver.Chrome(ChromeDriverManager().install())
    
    
#     try:
#         driver.get("https://www.youtube.com")
#         speak("what do you want to search?")
#         query = speechrecognition()
#         search_box = driver.find_element_by_name("search_query")
#         search_box.send_keys(query)
#         search_box.submit()
        
#         sleep(5)  # Wait for search results
        
#         video_link = driver.find_element_by_xpath('//*[@id="video-title"]')
#         video_link.click()
        
#         sleep(10)  # Wait for video to load
        
#         try:
#             skip_ad_button = driver.find_element_by_class_name("ytp-ad-skip-button-modern")
#             if skip_ad_button.is_displayed():
#                 skip_ad_button.click()
#                 print("Skipped the ad")
#                 sleep(5)  # Wait after skipping ad
#         except NoSuchElementException:
#             print("No skip ad button found or ad is not skippable.")
        
#         # Play the video (click the play button if needed)
#         play_button = driver.find_element_by_class_name("ytp-play-button")
#         if play_button.is_displayed():
#             play_button.click()
#             print("Playing the video")
        
#         # Wait for the video to play (adjust time if needed)
#         sleep(60)
    
#     except Exception as e:
#         print(f"An error occurred: {str(e)}")
    
#     finally:
#         driver.quit()

# # Example usage:
# song_query = "js promise by chai aur code"  # Change this to the desired song or video
# play_youtube_video(song_query)


import pyttsx3
import speech_recognition as sr
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.common.exceptions import NoSuchElementException
from time import sleep

def speak(text):
    engine = pyttsx3.init()
    Id = r'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices\Tokens\TTS_MS_EN-US_DAVID_11.0'
    engine.setProperty('voice', Id)
    print("")
    print(f"==> Eos AI : {text}")
    print("")
    engine.say(text=text)
    engine.runAndWait()

def take_input():
    # Check if the microphone is available
    mic_available = False
    mic_list = sr.Microphone.list_microphone_names()
    if "Microphone Array (Realtek(R) Au" in mic_list:
        mic_available = True

    if mic_available:
        try:
            query = speechrecognition()
            return query.lower()
        except Exception as e:
            print(f"An error occurred during voice input: {str(e)}")
            return None
    else:
        query = input("Enter your search query: ")
        return query.lower()

def speechrecognition():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening.....")
        r.pause_threshold = 1
        audio = r.listen(source, 0, 5)

    try:
        print("Recognizing....")
        query = r.recognize_google(audio, language="en")
        print(f"==> Person : {query}")
        return query.lower()

    except Exception as e:
        print(f"An error occurred during speech recognition: {str(e)}")
        return ""

def play_youtube_video(query):
    driver = webdriver.Chrome(ChromeDriverManager().install())

    try:
        driver.get("https://www.youtube.com")
        speak("What do you want to search?")
        query = take_input()

        if query:
            search_box = driver.find_element_by_name("search_query")
            search_box.send_keys(query)
            search_box.submit()

            sleep(5)  # Wait for search results

            video_link = driver.find_element_by_xpath('//*[@id="video-title"]')
            video_link.click()

            sleep(10)  # Wait for video to load

            try:
                skip_ad_button = driver.find_element_by_class_name("ytp-ad-skip-button-modern")
                if skip_ad_button.is_displayed():
                    skip_ad_button.click()
                    print("Skipped the ad")
                    sleep(5)  # Wait after skipping ad
            except NoSuchElementException:
                print("No skip ad button found or ad is not skippable.")

            # Play the video (click the play button if needed)
            play_button = driver.find_element_by_class_name("ytp-play-button")
            if play_button.is_displayed():
                play_button.click()
                print("Playing the video")

            # Wait for the video to play (adjust time if needed)
            sleep(60)

    except Exception as e:
        print(f"An error occurred: {str(e)}")

    finally:
        driver.quit()

# Example usage:
song_query = "js promise by chai aur code"  # Change this to the desired song or video
play_youtube_video(song_query)
